window.onload = function() {
    let valeurstyle = window.localStorage.getItem('style');
    if (valeurstyle !== undefined) {
        changestyle(valeurstyle);
    }


    let checkboxtheme = document.getElementById('chk'); //checkbox changement de theme
     checkboxtheme.addEventListener('click', function() {
        if (window.localStorage.getItem('style') === "style") {
            changestyle('style2'); //Style2

        } else {
            changestyle('style'); //style1
        }
    });

    // fonction pour changer le style de la page
    function changestyle(style) {
        console.log(style);
        let stylesheet = document.getElementById('linkcss');
        stylesheet.setAttribute('href', 'css/' + style + '.css');
        window.localStorage.setItem('style', style);

    }
}