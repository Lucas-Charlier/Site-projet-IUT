

const body = document.querySelector('body');
const scrollbar = document.querySelector('.scroller');



window.addEventListener('scroll',()=> {
    let scroll =  window.scrollY / (body.clientHeight - window.innerHeight);
    let scrollPercent = Math.round(scroll * 100);
    scrollbar.style.width = scrollPercent + '%';
})


window.addEventListener('scroll',() => {
        body.style.backgroundPositionX = window.scrollY * 1.5 + 'px';


})

/*
const jumbotron = document.querySelector('.jumbotron');
const block = document.querySelector('.titrePage');
let height = block.clientHeight;

window.addEventListener('scroll',() =>
{
    if (window.scrollY >= height) {
        jumbotron.classList.add('scroll');
    } else {
        jumbotron.classList.remove('scroll');
    }
}) */

/*
const chk = document.getElementById('chk');

chk.addEventListener('change', () => {
    document.body.classList.toggle('dark');

});*/

